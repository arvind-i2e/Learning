//Static methods and classes.
static class UseFullTool{
    static public void SayHi(string name){
        Console.WriteLine("Hello "+name);
    }
}//we can't create object of static class we can access it's static methods or static data directly from itself.