public class Printer{
    public void Print(IShape circle){
        Console.WriteLine(circle);
    }
}