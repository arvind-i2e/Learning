enum Level{
   
   jan,feb,mar,apr,may //class defination but with group of constants with 0-index by default.

}
