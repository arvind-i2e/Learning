class Player
    {
        public string Name = "Henry";
        public int health = 49;
        public void setHealth(int h)
        {
            health = h;
        }
    }

